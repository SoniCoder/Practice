-module(message).
-behaviour(baseinfo).

-include("../headers.hrl").

